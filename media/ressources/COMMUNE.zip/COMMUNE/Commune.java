




class Commune {
    String nom_commune;
    String code_postal;
    Citoyen citoyens[];
    Service services[];
    Depense depenses[];
    Recette recettes[];
    TypeService typeServices[];
    Mandat mandats[];

    

    double depenseDuMois(Daty Mois) {
        double Depensetotal = 0;
        for (Depense depense : depenses) {
            if (depense.dateDepense.mois == Mois.mois && depense.dateDepense.annee == Mois.annee) {
                Depensetotal += depense.montant;
            }
        }
        return Depensetotal;
    }

    double recetteDuMois(Daty Mois) {
        double Recettetotal = 0;
        for (Recette recette : recettes) {
            if (recette.dateRecette.mois == Mois.mois && recette.dateRecette.annee == Mois.annee) {
                Recettetotal += recette.montant;
            }
        }
        return Recettetotal;
    }

    double soldeDuMois(Daty Mois) {
        return recetteDuMois(Mois) - depenseDuMois(Mois);
    }
  
    int anneeLaPlusRentable() {
        double[] beneficesParAnnee = new double[6]; // 2020 à 2025
    
        for (int annee = 2020; annee <= 2025; annee++) {
            double beneficeAnnuel = 0;
    
            for (int mois = 1; mois <= 12; mois++) {
                Daty d = new Daty();
                d.jour = 1;
                d.mois = mois;
                d.annee = annee;
    
                beneficeAnnuel += soldeDuMois(d);
            }
    
            beneficesParAnnee[annee - 2020] = beneficeAnnuel;
        }
    
        int anneeMax = 2020;
        double max = beneficesParAnnee[0];
    
        for (int i = 1; i < 6; i++) {
            if (beneficesParAnnee[i] > max) {
                max = beneficesParAnnee[i];
                anneeMax = 2020 + i;
            }
        }
    
        return anneeMax;
    }

    String TypeServiePlusRenta() {
        TypeService typeServicePlusRenta = typeServices[0];
        for (int i = 0; i < typeServices.length; i++) {
            if (typeServices[i].prix > typeServicePlusRenta.prix) {
                typeServicePlusRenta = typeServices[i];
            }
        }
        return typeServicePlusRenta.intitule;
    }

    double beneficeParAn(int annee) {
        double total = 0;
        for (int mois = 1; mois <= 12; mois++) {
            Daty d = new Daty();
            d.jour = 1;
            d.mois = mois;
            d.annee = annee;
            total += soldeDuMois(d);
        }
        return total;
    }

    double beneficeDuMandat(Mandat m) {
        double total = 0;
        for (int annee = m.anneeDebut; annee <= m.anneeFin; annee++) {
            total += beneficeParAn(annee);
        }
        return total;
    }

    Citoyen maireLePlusRentable() {
        Mandat meilleur = mandats[0];
        double max = beneficeDuMandat(mandats[0]);

        for (int i = 1; i < mandats.length; i++) {
            double benef = beneficeDuMandat(mandats[i]);
            if (benef > max) {
                max = benef;
                meilleur = mandats[i];
            }
        }

        return meilleur.maire;
    }
    
    //LES DEUX SERVICES LES PLUS RENTABLES
    TypeService[] typesServicesRenta() {
        double[] totalParType = new double[typeServices.length];
    
        for (Service service : services) {
            for (int i = 0; i < typeServices.length; i++) {
                if (service.typeServices.equals(typeServices[i])) {
                    totalParType[i] += typeServices[i].prix;
                }
            }
        }
    
        int indexMax1 = 0;
        int indexMax2 = -1;
    
        for (int i = 1; i < totalParType.length; i++) {
            if (totalParType[i] > totalParType[indexMax1]) {
                indexMax2 = indexMax1;
                indexMax1 = i;
            } else if (indexMax2 == -1 || totalParType[i] > totalParType[indexMax2]) {
                indexMax2 = i;
            }
        }
    
        TypeService[] meilleurs = new TypeService[2];
        meilleurs[0] = typeServices[indexMax1];
        meilleurs[1] = typeServices[indexMax2];
    
        return meilleurs;
    }
    


}