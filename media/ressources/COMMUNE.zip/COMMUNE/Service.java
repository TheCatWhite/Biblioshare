class Service {
    TypeService typeServices;
    Daty dateService;
}