class Citoyen{
	String nom;
	String prenom;
	Daty annee_naissance;
	String lieu_naissance;
	String numeroCIN;
	Citoyen pere;
	Citoyen mere;


	void presentation() {
		System.out.println("________________________________________________\n\n");
		System.out.println("    Nom : " + this.nom);
		System.out.println(" Prenom : " + this.prenom);
		System.out.println("  né le : " + this.annee_naissance.jour + "/" + this.annee_naissance.mois + "/"+ this.annee_naissance.annee);
		System.out.println("      à : "+ this.lieu_naissance);
		System.out.println("    CIN : " + this.numeroCIN);
		System.out.println("    Père: " + this.pere.nom + " " + this.pere.prenom);
		System.out.println("    Mère: " + this.mere.nom + " " + this.mere.prenom);
		System.out.println("________________________________________________\n\n");
	
	}

}