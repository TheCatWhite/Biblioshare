class Recette {
    String intitule;
    Daty dateRecette;
    double montant;
}