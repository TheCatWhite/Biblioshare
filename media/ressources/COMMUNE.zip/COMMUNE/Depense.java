class Depense {
    String intitule;
    Daty dateDepense;
    double montant;
    
}