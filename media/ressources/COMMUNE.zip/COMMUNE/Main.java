public class Main{
	public static void main(String[] args){


		//creation des dates de naissance des parents

		Daty mere_date_naissance= new Daty();
		mere_date_naissance.jour=31;
		mere_date_naissance.mois=2;
		mere_date_naissance.annee=1980;

		Daty pere_date_naissance= new Daty();
		pere_date_naissance.jour=24;
		pere_date_naissance.mois=12;
		pere_date_naissance.annee=1970;

		//DATE NAISSANCE CITOYENS
		Daty first_date_naissance= new Daty();
		first_date_naissance.jour=12;
		first_date_naissance.mois=3;
		first_date_naissance.annee = 2000;

		Daty second_date_naissance= new Daty();
		second_date_naissance.jour=14;
		second_date_naissance.mois=02;
		second_date_naissance.annee = 2006;

			//CREATION DE DATE DE SERVICE 
			Daty dateservice=new Daty();
			dateservice.jour=15;
			dateservice.mois=3;
			dateservice.annee = 2023;
			
			//CREATION DE DATE DE SERVICE 
			Daty dateservice2=new Daty();
			dateservice2.jour=12;
			dateservice2.mois=6;
			dateservice2.annee = 2024;
				
					//Creation de date de depense
					Daty datedepense = new Daty();
					datedepense.jour=26;
					datedepense.mois=3;
					datedepense.annee = 2023;
					//Creation de date de depense
					Daty datedepense2 = new Daty();
					datedepense2.jour=22;
					datedepense2.mois=3;
					datedepense2.annee = 2024;

					Daty datedepense3 = new Daty();
					datedepense3.jour=26;
					datedepense3.mois = 12;
					datedepense3.annee = 2024;

					//CREATION DE DATE DE RECETTE
					Daty daterecette = new Daty();
					daterecette.jour=26;
					daterecette.mois=12;
					daterecette.annee = 2023;
		
		//Creation des pères
		Citoyen firstpere =new Citoyen();
		firstpere.nom="Dada";
		firstpere.prenom="Deba";
		firstpere.annee_naissance= pere_date_naissance;
		firstpere.lieu_naissance="Antanimena";
		firstpere.numeroCIN="1237689";


		Citoyen firstmere =new Citoyen();
		firstmere.nom="Mama";
		firstmere.prenom="Nivo";
		firstmere.annee_naissance= mere_date_naissance;
		firstmere.lieu_naissance="Antanimena";
		firstmere.numeroCIN = "1237689";

		Citoyen therdpere =new Citoyen();
		therdpere.nom="RAKOTO";
		therdpere.prenom="Nicolas";
		therdpere.annee_naissance= pere_date_naissance;
		therdpere.lieu_naissance="BETROKA";
		therdpere.numeroCIN="9947689";


		Citoyen therdmere =new Citoyen();
		therdmere.nom="NILAINA";
		therdmere.prenom="Nirina";
		therdmere.annee_naissance= mere_date_naissance;
		therdmere.lieu_naissance="Beefelatanana";
		therdmere.numeroCIN = "6437689";



		//CREATION DES CITOENS

		//FIRST CITOYEN
		Citoyen firstCit= new Citoyen();
		firstCit.nom = "RAKOTOVAO";
		firstCit.prenom= "Joyce";
		firstCit.annee_naissance= first_date_naissance;
		firstCit.lieu_naissance="Tamatave";
		firstCit.numeroCIN="12343560";
		firstCit.pere=firstpere;
		firstCit.mere = firstmere;
		firstCit.presentation();

		//SECOND CITOYEN
		Citoyen secondCit= new Citoyen();
		secondCit.nom = "RANDRIANJATO ";
		secondCit.prenom= "Stella";
		secondCit.annee_naissance= second_date_naissance;
		secondCit.lieu_naissance="Tamatave";
		secondCit.numeroCIN="19863560";
		secondCit.pere=firstpere;
		secondCit.mere = firstmere;
		secondCit.presentation();

		//THERD CITOYEN
		Citoyen therdCit= new Citoyen();
		therdCit.nom = "RAZAFINDRABE";
		therdCit.prenom= "Felix";
		therdCit.annee_naissance= second_date_naissance;
		therdCit.lieu_naissance="Morondava";
		therdCit.numeroCIN="19347889";
		therdCit.pere=firstpere;
		therdCit.mere = firstmere;

		therdCit.presentation();

		//CREATION DE TYPE DE SERVICE
		//tyoe de service 1
		TypeService typeService1 = new TypeService();
		typeService1.intitule = "Acte de naissance";
		typeService1.prix = 10000;

				//type de service 2
				TypeService typeService2 = new TypeService();
				typeService2.intitule = "Acte de marriage";
				typeService2.prix = 15000;


		//CREATION DE SERVICE DE LA COMMUNE

		//Service 1
		Service service1 = new Service();
		service1.typeServices = typeService1;
		service1.dateService = dateservice;

		//Service 1
		Service service2 = new Service();
		service2.typeServices = typeService2;
		service2.dateService = dateservice2;


		//CREATION DE DEPENSE

		//Depense 1
		Depense depense1 = new Depense();
		depense1.intitule = "200 papier A4";
		depense1.montant = 5000;
		depense1.dateDepense = datedepense;

		//Depense 2
		Depense depense2 = new Depense();
		depense2.intitule = "100 enveloppes";
		depense2.montant = 7000;
		depense2.dateDepense = datedepense;
		

		//depnse3

		Depense depense3 = new Depense();
		depense3.intitule = "Frais de fonctionnement";
		depense3.montant = 10000;
		depense3.dateDepense = datedepense3;

		//CREATION DE RECETTE 
		Recette recette1 = new Recette();
		recette1.intitule = "Recette Service 1";
		recette1.montant = 90000;
		recette1.dateRecette = dateservice;

		Recette recette2 = new Recette();
		recette2.intitule = "Recette Service 2";
		recette2.montant = 80000;
		recette2.dateRecette = dateservice2;

		//AFFICHAGE DES INFORMATIONS DE LA COMMUNE
		Mandat mandat = new Mandat();
		mandat.maire = firstCit;
		mandat.anneeDebut = 2020;
		mandat.anneeFin = 2025;

		//CREATION DE COMMUNE
		Commune commune = new Commune();
		commune.nom_commune = "Antanimena";
		commune.code_postal = "101";
		commune.citoyens = new Citoyen[3];
		commune.citoyens[0] = firstCit;
		commune.citoyens[1] = secondCit;
		commune.citoyens[2] = therdCit;
		commune.services = new Service[2];
		commune.services[0] = service1;
		commune.services[1] = service2;
		commune.depenses = new Depense[3];
		commune.depenses[0] = depense1;
		commune.depenses[1] = depense2;
		commune.depenses[2] = depense3;
		commune.recettes = new Recette[2];
		commune.recettes[0] = recette1;
		commune.recettes[1] = recette2;
		commune.typeServices = new TypeService[2];
		commune.typeServices[0] = typeService1;
		commune.typeServices[1] = typeService2;
		commune.mandats = new Mandat[1];
		commune.mandats[0] = mandat;
		
		






		System.out.println("L'année la plus rentable est : " + commune.anneeLaPlusRentable());
		System.out.println("Le Type de service le plus rentable est : " + commune.TypeServiePlusRenta());
		System.out.println("Le Maire qui a fait rentrer le plus d' argent est : "+ commune.maireLePlusRentable().nom);
		System.out.println("Les deux services les plus rentables sont : "+ commune.typesServicesRenta()[0].intitule + " et " + commune.typesServicesRenta()[1].intitule);

	}
}