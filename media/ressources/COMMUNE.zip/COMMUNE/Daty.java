class Daty{
	int jour;
	int mois;
	int annee;
}