class TypeService {
    String intitule;
    double prix;
}