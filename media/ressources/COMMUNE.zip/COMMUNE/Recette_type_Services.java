class Recette_type_Services {
    TypeService typeServices[];
    double recetteTotalDeTypeService
}
