class Mandat {
    Citoyen maire;
    int anneeDebut;
    int anneeFin;
}
